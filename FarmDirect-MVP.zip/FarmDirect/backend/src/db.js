import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const db = new Database(path.join(__dirname, "../farmdirect.db"));

db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('farmer','supplier','admin')),
  location TEXT DEFAULT '',
  verified INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS crops (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  farmer_id INTEGER NOT NULL,
  crop_name TEXT NOT NULL,
  quantity REAL NOT NULL,
  quality TEXT NOT NULL,
  expected_price REAL NOT NULL,
  location TEXT NOT NULL,
  available_date TEXT,
  description TEXT DEFAULT '',
  status TEXT DEFAULT 'active',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(farmer_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  crop_id INTEGER NOT NULL,
  supplier_id INTEGER NOT NULL,
  quantity REAL NOT NULL,
  price REAL NOT NULL,
  message TEXT DEFAULT '',
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(crop_id) REFERENCES crops(id),
  FOREIGN KEY(supplier_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS deals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  crop_id INTEGER NOT NULL,
  farmer_id INTEGER NOT NULL,
  supplier_id INTEGER NOT NULL,
  offer_id INTEGER NOT NULL,
  quantity REAL NOT NULL,
  final_price REAL NOT NULL,
  total_amount REAL NOT NULL,
  status TEXT DEFAULT 'confirmed',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(crop_id) REFERENCES crops(id),
  FOREIGN KEY(farmer_id) REFERENCES users(id),
  FOREIGN KEY(supplier_id) REFERENCES users(id),
  FOREIGN KEY(offer_id) REFERENCES offers(id)
);
`);

export default db;
