import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import db from "./db.js";
import { signToken, requireAuth, requireRole } from "./auth.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());

const clean = (v) => String(v ?? "").trim();

app.get("/api/health", (_, res) => res.json({ ok: true, service: "FarmDirect API" }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const name = clean(req.body.name);
    const phone = clean(req.body.phone);
    const password = clean(req.body.password);
    const role = clean(req.body.role);
    const location = clean(req.body.location);

    if (!name || !phone || !password || !["farmer", "supplier"].includes(role)) {
      return res.status(400).json({ message: "Name, phone, password and valid role are required" });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: "Password must be at least 6 characters" });
    }

    const exists = db.prepare("SELECT id FROM users WHERE phone=?").get(phone);
    if (exists) return res.status(409).json({ message: "Phone already registered" });

    const hash = await bcrypt.hash(password, 10);
    const result = db.prepare(`
      INSERT INTO users (name, phone, password_hash, role, location)
      VALUES (?, ?, ?, ?, ?)
    `).run(name, phone, hash, role, location);

    const user = db.prepare("SELECT id,name,phone,role,location,verified FROM users WHERE id=?")
      .get(result.lastInsertRowid);

    res.status(201).json({ user, token: signToken(user) });
  } catch (e) {
    res.status(500).json({ message: "Registration failed" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const phone = clean(req.body.phone);
  const password = clean(req.body.password);
  const user = db.prepare("SELECT * FROM users WHERE phone=?").get(phone);

  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ message: "Invalid phone or password" });
  }

  const safe = {
    id: user.id, name: user.name, phone: user.phone,
    role: user.role, location: user.location, verified: user.verified
  };
  res.json({ user: safe, token: signToken(safe) });
});

app.get("/api/me", requireAuth, (req, res) => {
  const user = db.prepare(`
    SELECT id,name,phone,role,location,verified,created_at
    FROM users WHERE id=?
  `).get(req.user.id);
  res.json(user);
});

app.post("/api/crops", requireAuth, requireRole("farmer"), (req, res) => {
  const { crop_name, quantity, quality, expected_price, location, available_date, description } = req.body;
  if (!crop_name || !quantity || !quality || !expected_price || !location) {
    return res.status(400).json({ message: "Crop, quantity, quality, price and location are required" });
  }

  const result = db.prepare(`
    INSERT INTO crops
    (farmer_id,crop_name,quantity,quality,expected_price,location,available_date,description)
    VALUES (?,?,?,?,?,?,?,?)
  `).run(
    req.user.id, clean(crop_name), Number(quantity), clean(quality),
    Number(expected_price), clean(location), clean(available_date), clean(description)
  );

  res.status(201).json(
    db.prepare("SELECT * FROM crops WHERE id=?").get(result.lastInsertRowid)
  );
});

app.get("/api/crops", requireAuth, (req, res) => {
  const q = clean(req.query.q);
  const rows = q
    ? db.prepare(`
      SELECT c.*, u.name farmer_name, u.verified farmer_verified
      FROM crops c JOIN users u ON u.id=c.farmer_id
      WHERE c.status='active' AND c.crop_name LIKE ?
      ORDER BY c.created_at DESC
    `).all(`%${q}%`)
    : db.prepare(`
      SELECT c.*, u.name farmer_name, u.verified farmer_verified
      FROM crops c JOIN users u ON u.id=c.farmer_id
      WHERE c.status='active'
      ORDER BY c.created_at DESC
    `).all();

  res.json(rows);
});

app.get("/api/farmer/crops", requireAuth, requireRole("farmer"), (req, res) => {
  res.json(db.prepare(`
    SELECT c.*,
      (SELECT COUNT(*) FROM offers o WHERE o.crop_id=c.id) offer_count
    FROM crops c
    WHERE c.farmer_id=?
    ORDER BY c.created_at DESC
  `).all(req.user.id));
});

app.post("/api/offers", requireAuth, requireRole("supplier"), (req, res) => {
  const cropId = Number(req.body.crop_id);
  const quantity = Number(req.body.quantity);
  const price = Number(req.body.price);
  const message = clean(req.body.message);

  const crop = db.prepare("SELECT * FROM crops WHERE id=? AND status='active'").get(cropId);
  if (!crop) return res.status(404).json({ message: "Crop listing not found" });
  if (!quantity || quantity <= 0 || !price || price <= 0) {
    return res.status(400).json({ message: "Valid quantity and price are required" });
  }
  if (crop.farmer_id === req.user.id) {
    return res.status(400).json({ message: "You cannot offer on your own listing" });
  }

  const result = db.prepare(`
    INSERT INTO offers (crop_id,supplier_id,quantity,price,message)
    VALUES (?,?,?,?,?)
  `).run(cropId, req.user.id, quantity, price, message);

  res.status(201).json(
    db.prepare("SELECT * FROM offers WHERE id=?").get(result.lastInsertRowid)
  );
});

app.get("/api/offers/received", requireAuth, requireRole("farmer"), (req, res) => {
  res.json(db.prepare(`
    SELECT o.*, c.crop_name, c.quantity crop_quantity,
           u.name supplier_name, u.verified supplier_verified
    FROM offers o
    JOIN crops c ON c.id=o.crop_id
    JOIN users u ON u.id=o.supplier_id
    WHERE c.farmer_id=?
    ORDER BY o.created_at DESC
  `).all(req.user.id));
});

app.get("/api/offers/sent", requireAuth, requireRole("supplier"), (req, res) => {
  res.json(db.prepare(`
    SELECT o.*, c.crop_name, c.location,
           u.name farmer_name
    FROM offers o
    JOIN crops c ON c.id=o.crop_id
    JOIN users u ON u.id=c.farmer_id
    WHERE o.supplier_id=?
    ORDER BY o.created_at DESC
  `).all(req.user.id));
});

app.post("/api/offers/:id/accept", requireAuth, requireRole("farmer"), (req, res) => {
  const offer = db.prepare(`
    SELECT o.*, c.farmer_id, c.status crop_status
    FROM offers o JOIN crops c ON c.id=o.crop_id
    WHERE o.id=?
  `).get(Number(req.params.id));

  if (!offer || offer.farmer_id !== req.user.id) {
    return res.status(404).json({ message: "Offer not found" });
  }
  if (offer.status !== "pending" || offer.crop_status !== "active") {
    return res.status(400).json({ message: "Offer is no longer available" });
  }

  const tx = db.transaction(() => {
    db.prepare("UPDATE offers SET status='accepted' WHERE id=?").run(offer.id);
    db.prepare(`
      UPDATE offers SET status='rejected'
      WHERE crop_id=? AND id<>? AND status='pending'
    `).run(offer.crop_id, offer.id);

    db.prepare("UPDATE crops SET status='sold' WHERE id=?").run(offer.crop_id);

    const result = db.prepare(`
      INSERT INTO deals
      (crop_id,farmer_id,supplier_id,offer_id,quantity,final_price,total_amount)
      VALUES (?,?,?,?,?,?,?)
    `).run(
      offer.crop_id, offer.farmer_id, offer.supplier_id, offer.id,
      offer.quantity, offer.price, offer.quantity * offer.price
    );
    return result.lastInsertRowid;
  });

  const dealId = tx();
  res.json(db.prepare("SELECT * FROM deals WHERE id=?").get(dealId));
});

app.post("/api/offers/:id/reject", requireAuth, requireRole("farmer"), (req, res) => {
  const offer = db.prepare(`
    SELECT o.id,c.farmer_id FROM offers o
    JOIN crops c ON c.id=o.crop_id WHERE o.id=?
  `).get(Number(req.params.id));

  if (!offer || offer.farmer_id !== req.user.id) {
    return res.status(404).json({ message: "Offer not found" });
  }
  db.prepare("UPDATE offers SET status='rejected' WHERE id=?").run(offer.id);
  res.json({ ok: true });
});

app.get("/api/deals", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT d.*, c.crop_name,
           f.name farmer_name, s.name supplier_name
    FROM deals d
    JOIN crops c ON c.id=d.crop_id
    JOIN users f ON f.id=d.farmer_id
    JOIN users s ON s.id=d.supplier_id
    WHERE d.farmer_id=? OR d.supplier_id=?
    ORDER BY d.created_at DESC
  `).all(req.user.id, req.user.id);
  res.json(rows);
});

app.listen(PORT, () => {
  console.log(`FarmDirect API running on http://localhost:${PORT}`);
});
