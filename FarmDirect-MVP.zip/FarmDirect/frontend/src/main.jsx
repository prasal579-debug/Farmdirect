import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Sprout, Plus, Search, Bell, UserRound, LayoutDashboard,
  Wheat, HandCoins, Truck, LogOut, CheckCircle2, XCircle
} from "lucide-react";
import "./styles.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

async function api(path, options = {}) {
  const token = localStorage.getItem("farmdirect_token");
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(API + path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Something went wrong");
  return data;
}

function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("home");

  useEffect(() => {
    const token = localStorage.getItem("farmdirect_token");
    if (token) api("/me").then(setUser).catch(() => localStorage.removeItem("farmdirect_token"));
  }, []);

  const logout = () => {
    localStorage.removeItem("farmdirect_token");
    setUser(null);
  };

  if (!user) return <Auth onLogin={setUser} />;

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand"><Sprout size={28}/> FarmDirect</div>
        <div className="top-actions">
          <Bell size={20}/>
          <span>{user.name}</span>
          <button className="icon-btn" onClick={logout}><LogOut size={18}/></button>
        </div>
      </header>

      <div className="layout">
        <aside className="sidebar">
          <button className={page==="home"?"active":""} onClick={()=>setPage("home")}><LayoutDashboard/> Dashboard</button>
          {user.role === "farmer" && <>
            <button className={page==="add"?"active":""} onClick={()=>setPage("add")}><Plus/> Sell Crop</button>
            <button className={page==="offers"?"active":""} onClick={()=>setPage("offers")}><HandCoins/> Offers</button>
          </>}
          {user.role === "supplier" && <>
            <button className={page==="market"?"active":""} onClick={()=>setPage("market")}><Search/> Find Crops</button>
            <button className={page==="sent"?"active":""} onClick={()=>setPage("sent")}><HandCoins/> My Offers</button>
          </>}
          <button className={page==="deals"?"active":""} onClick={()=>setPage("deals")}><Truck/> Deals</button>
          <button onClick={logout}><LogOut/> Logout</button>
        </aside>

        <main className="content">
          {page==="home" && <Dashboard user={user} go={setPage}/>}
          {page==="add" && <AddCrop go={setPage}/>}
          {page==="offers" && <FarmerOffers/>}
          {page==="market" && <Market/>}
          {page==="sent" && <SentOffers/>}
          {page==="deals" && <Deals/>}
        </main>
      </div>
    </div>
  );
}

function Auth({onLogin}) {
  const [mode,setMode] = useState("login");
  const [role,setRole] = useState("farmer");
  const [form,setForm] = useState({name:"",phone:"",password:"",location:""});
  const [error,setError] = useState("");

  const submit = async e => {
    e.preventDefault(); setError("");
    try {
      const data = await api(mode==="login" ? "/auth/login" : "/auth/register", {
        method:"POST",
        body: JSON.stringify(mode==="login" ? {phone:form.phone,password:form.password} : {...form,role})
      });
      localStorage.setItem("farmdirect_token", data.token);
      onLogin(data.user);
    } catch(e) { setError(e.message); }
  };

  return <div className="auth-page">
    <div className="auth-card">
      <div className="logo-big"><Sprout size={42}/></div>
      <h1>FarmDirect</h1>
      <p className="muted">Direct farm-to-supplier marketplace</p>
      <div className="tabs">
        <button className={mode==="login"?"selected":""} onClick={()=>setMode("login")}>Login</button>
        <button className={mode==="register"?"selected":""} onClick={()=>setMode("register")}>Register</button>
      </div>
      <form onSubmit={submit}>
        {mode==="register" && <input placeholder="Full name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>}
        <input placeholder="Mobile number" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/>
        <input type="password" placeholder="Password (6+ characters)" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
        {mode==="register" && <>
          <div className="role-grid">
            <button type="button" className={role==="farmer"?"role selected": "role"} onClick={()=>setRole("farmer")}>👨‍🌾 Farmer</button>
            <button type="button" className={role==="supplier"?"role selected": "role"} onClick={()=>setRole("supplier")}>🏭 Supplier</button>
          </div>
          <input placeholder="Village / City" value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/>
        </>}
        {error && <div className="error">{error}</div>}
        <button className="primary wide">{mode==="login"?"Login":"Create Account"}</button>
      </form>
    </div>
  </div>
}

function Dashboard({user,go}) {
  const [stats,setStats] = useState({crops:0,offers:0,deals:0});
  useEffect(()=> {
    Promise.all([
      user.role==="farmer" ? api("/farmer/crops") : api("/crops"),
      user.role==="farmer" ? api("/offers/received") : api("/offers/sent"),
      api("/deals")
    ]).then(([a,b,c])=>setStats({crops:a.length,offers:b.length,deals:c.length}));
  },[user]);

  return <div>
    <div className="hero">
      <div>
        <p className="eyebrow">WELCOME BACK</p>
        <h2>Hello, {user.name} 👋</h2>
        <p className="muted">{user.role==="farmer" ? "Sell your harvest directly to verified suppliers." : "Find quality crops directly from farmers."}</p>
      </div>
      {user.role==="farmer" && <button className="primary" onClick={()=>go("add")}><Plus/> Sell Crop</button>}
      {user.role==="supplier" && <button className="primary" onClick={()=>go("market")}><Search/> Find Crops</button>}
    </div>

    <div className="stats">
      <Stat icon={<Wheat/>} title={user.role==="farmer"?"My Listings":"Available Crops"} value={stats.crops}/>
      <Stat icon={<HandCoins/>} title="Offers" value={stats.offers}/>
      <Stat icon={<Truck/>} title="Deals" value={stats.deals}/>
    </div>

    <div className="card">
      <h3>How FarmDirect works</h3>
      <div className="steps">
        <Step n="1" title="List" text="Farmer posts crop, quantity and expected price."/>
        <Step n="2" title="Offer" text="Verified suppliers send price offers."/>
        <Step n="3" title="Deal" text="Farmer accepts the best offer."/>
        <Step n="4" title="Pickup" text="Supplier arranges pickup and delivery."/>
      </div>
    </div>
  </div>
}

function Stat({icon,title,value}) {
  return <div className="stat card"><div className="stat-icon">{icon}</div><div><div className="muted">{title}</div><strong>{value}</strong></div></div>
}
function Step({n,title,text}) { return <div className="step"><span>{n}</span><div><b>{title}</b><p>{text}</p></div></div> }

function AddCrop({go}) {
  const [f,setF]=useState({crop_name:"Onion",quantity:"",quality:"A Grade",expected_price:"",location:"",available_date:"",description:""});
  const [msg,setMsg]=useState("");
  const submit=async e=>{
    e.preventDefault();
    try { await api("/crops",{method:"POST",body:JSON.stringify(f)}); setMsg("Crop listed successfully."); setTimeout(()=>go("home"),700); }
    catch(e){setMsg(e.message)}
  };
  return <div className="card form-card"><h2>Sell Your Crop 🌾</h2><p className="muted">Add accurate information so suppliers can make better offers.</p>
    <form onSubmit={submit} className="form-grid">
      <label>Crop<select value={f.crop_name} onChange={e=>setF({...f,crop_name:e.target.value})}><option>Onion</option><option>Tomato</option><option>Potato</option><option>Wheat</option><option>Soybean</option><option>Other</option></select></label>
      <label>Quantity (kg)<input type="number" min="1" value={f.quantity} onChange={e=>setF({...f,quantity:e.target.value})} required/></label>
      <label>Quality<select value={f.quality} onChange={e=>setF({...f,quality:e.target.value})}><option>A Grade</option><option>B Grade</option><option>Standard</option></select></label>
      <label>Expected Price (₹/kg)<input type="number" step="0.01" min="0.01" value={f.expected_price} onChange={e=>setF({...f,expected_price:e.target.value})} required/></label>
      <label>Pickup Location<input value={f.location} onChange={e=>setF({...f,location:e.target.value})} required/></label>
      <label>Available Date<input type="date" value={f.available_date} onChange={e=>setF({...f,available_date:e.target.value})}/></label>
      <label className="full">Description<textarea value={f.description} onChange={e=>setF({...f,description:e.target.value})} placeholder="Quality details, packaging, etc."/></label>
      {msg && <div className="notice full">{msg}</div>}
      <button className="primary full">Post Crop</button>
    </form>
  </div>
}

function FarmerOffers() {
  const [offers,setOffers]=useState([]); const [msg,setMsg]=useState("");
  const load=()=>api("/offers/received").then(setOffers).catch(e=>setMsg(e.message));
  useEffect(load,[]);
  const action=async(id,type)=>{
    try { await api(`/offers/${id}/${type}`,{method:"POST"}); setMsg(type==="accept"?"Deal confirmed!":"Offer rejected."); load(); }
    catch(e){setMsg(e.message)}
  };
  return <div><h2>Offers Received</h2><p className="muted">Compare supplier prices before confirming a deal.</p>{msg&&<div className="notice">{msg}</div>}
    <div className="list">{offers.length===0?<Empty text="No offers yet."/>:offers.map(o=><div className="card offer" key={o.id}>
      <div><h3>{o.crop_name}</h3><p>{o.supplier_name} {o.supplier_verified?<span className="verified">✓ Verified</span>:""}</p><p className="muted">{o.quantity} kg · {o.message||"No message"}</p></div>
      <div className="offer-price">₹{o.price}/kg</div>
      {o.status==="pending" && <div className="actions"><button className="primary" onClick={()=>action(o.id,"accept")}><CheckCircle2/> Accept</button><button className="danger" onClick={()=>action(o.id,"reject")}><XCircle/> Reject</button></div>}
      <span className={`badge ${o.status}`}>{o.status}</span>
    </div>)}</div>
  </div>
}

function Market() {
  const [q,setQ]=useState(""); const [crops,setCrops]=useState([]); const [selected,setSelected]=useState(null); const [f,setF]=useState({quantity:"",price:"",message:""}); const [msg,setMsg]=useState("");
  const load=()=>api("/crops?q="+encodeURIComponent(q)).then(setCrops).catch(e=>setMsg(e.message));
  useEffect(load,[]);
  const submit=async e=>{
    e.preventDefault();
    try { await api("/offers",{method:"POST",body:JSON.stringify({crop_id:selected.id,...f})}); setMsg("Offer sent successfully."); setSelected(null); setF({quantity:"",price:"",message:""}); }
    catch(e){setMsg(e.message)}
  };
  return <div><div className="page-head"><div><h2>Find Crops</h2><p className="muted">Browse farmer listings and make an offer.</p></div><div className="search"><Search size={18}/><input placeholder="Search onion, tomato..." value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&load()}/></div></div>
    {msg&&<div className="notice">{msg}</div>}
    <div className="crop-grid">{crops.length===0?<Empty text="No crop listings found."/>:crops.map(c=><div className="card crop" key={c.id}>
      <div className="crop-emoji">{c.crop_name==="Onion"?"🧅":c.crop_name==="Tomato"?"🍅":c.crop_name==="Potato"?"🥔":"🌾"}</div>
      <h3>{c.crop_name}</h3><p>{c.quantity} kg · {c.quality}</p><p>📍 {c.location}</p><p className="expected">Expected ₹{c.expected_price}/kg</p><button className="primary wide" onClick={()=>setSelected(c)}>Make Offer</button>
    </div>)}</div>
    {selected&&<div className="modal-bg"><div className="modal card"><button className="close" onClick={()=>setSelected(null)}>×</button><h2>Make Offer</h2><p>{selected.crop_name} · {selected.quantity} kg · {selected.location}</p><form onSubmit={submit}>
      <label>Quantity (kg)<input type="number" min="1" max={selected.quantity} required value={f.quantity} onChange={e=>setF({...f,quantity:e.target.value})}/></label>
      <label>Your Price (₹/kg)<input type="number" step="0.01" min="0.01" required value={f.price} onChange={e=>setF({...f,price:e.target.value})}/></label>
      <label>Message<textarea value={f.message} onChange={e=>setF({...f,message:e.target.value})} placeholder="Pickup and quality message"/></label>
      <button className="primary wide">Send Offer</button>
    </form></div></div>}
  </div>
}

function SentOffers(){ const [rows,setRows]=useState([]); useEffect(()=>api("/offers/sent").then(setRows),[]); return <div><h2>My Offers</h2><div className="list">{rows.length===0?<Empty text="No offers sent yet."/>:rows.map(o=><div className="card offer" key={o.id}><div><h3>{o.crop_name}</h3><p>{o.farmer_name} · {o.location}</p></div><div className="offer-price">₹{o.price}/kg</div><span className={`badge ${o.status}`}>{o.status}</span></div>)}</div></div> }

function Deals(){ const [rows,setRows]=useState([]); useEffect(()=>api("/deals").then(setRows),[]); return <div><h2>Deals</h2><p className="muted">Track confirmed transactions.</p><div className="list">{rows.length===0?<Empty text="No deals yet."/>:rows.map(d=><div className="card deal" key={d.id}><div><h3>Deal #{d.id}</h3><p>{d.crop_name} · {d.quantity} kg</p><p>{d.farmer_name} ↔ {d.supplier_name}</p></div><div><strong>₹{Number(d.total_amount).toLocaleString("en-IN")}</strong><p className="muted">₹{d.final_price}/kg</p></div><span className="badge confirmed">confirmed</span></div>)}</div></div> }

function Empty({text}){return <div className="empty card">{text}</div>}

createRoot(document.getElementById("root")).render(<App />);
