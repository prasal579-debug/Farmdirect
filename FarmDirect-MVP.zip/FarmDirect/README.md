# FarmDirect 🌾

Farmer-to-Supplier marketplace MVP.

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: SQLite (better-sqlite3)
- Auth: JWT
- UI: Responsive CSS

## Features
- Farmer / Supplier registration and login
- Farmer can post crop listings
- Suppliers can browse crops and make offers
- Farmers can accept/reject offers
- Deal creation after accepting an offer
- Basic dashboard
- SQLite database
- REST API

## Run

### 1. Backend
```bash
cd backend
npm install
npm run dev
```
Backend runs at `http://localhost:5000`

### 2. Frontend
Open another terminal:
```bash
cd frontend
npm install
npm run dev
```
Frontend runs at the Vite URL, usually `http://localhost:5173`

## Demo users
You can register from the UI. No real payment or WhatsApp integration is enabled in this MVP.

## Production next steps
- Firebase/OTP authentication
- KYC and supplier verification
- Razorpay/UPI payment flow
- WhatsApp Business API
- Google Maps and pickup tracking
- Cloud image storage
- Rate limiting, audit logs and stronger authorization
